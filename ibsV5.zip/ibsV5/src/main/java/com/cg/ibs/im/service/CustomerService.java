package com.cg.ibs.im.service;

import java.io.FileNotFoundException;
import java.time.LocalDate;

import com.cg.ibs.im.bean.AddressBean;
import com.cg.ibs.im.bean.ApplicantBean;
import com.cg.ibs.im.bean.ApplicantStatus;
import com.cg.ibs.im.bean.CustomerBean;
import com.cg.ibs.im.exception.IBSCustomException;

public interface CustomerService {
boolean verifyApplicantId(long applicantId) throws IBSCustomException;
	
	ApplicantStatus checkStatus(Long applicantId) throws IBSCustomException;
	
	boolean login(String username, String password) throws IBSCustomException;
	
	boolean verifyName(String name);

	boolean verifyDob(LocalDate ld);

	boolean verifyMobileNumber(String mobileNumber);

	boolean verifyAadharNumber(String aadharNumber);

	boolean verifyPincode(String pinCode);

	boolean verifyPanNumber(String panNumber);

	boolean verifyEmailId(String emailId);

	boolean verifyMobileNumbers(String mobile1, String mobile2);

	boolean checkCustomerDetails(String confirm1, String confirm2);

	Long saveApplicantDetails(ApplicantBean applicant) throws IBSCustomException;

	boolean saveCustomerDetails(CustomerBean customerBean) throws IBSCustomException;

	CustomerBean getCustomerDetails(String uci) throws IBSCustomException;

	boolean firstLogin(String userUci) throws IBSCustomException;

	ApplicantBean getApplicantDetails(Long applicantId) throws IBSCustomException;

	CustomerBean getCustomerByApplicantId(Long applicantId) throws IBSCustomException;

	boolean isCustomerValid(String uci) throws IBSCustomException;

	boolean upload(String srcPath) throws IBSCustomException;

	Long saveAddress(AddressBean address) throws IBSCustomException;
	
	boolean updateApplicant(ApplicantBean applicant) throws IBSCustomException;

	boolean updateCustomer(CustomerBean customer) throws IBSCustomException;

	void uploadDocuments(ApplicantBean applicant, String aadharPath, String panPath) throws IBSCustomException, FileNotFoundException;

}
