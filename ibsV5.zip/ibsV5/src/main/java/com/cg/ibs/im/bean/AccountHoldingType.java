package com.cg.ibs.im.bean;

public enum AccountHoldingType {
	PRIMARY, SECONDARY, INDIVIDUAL;
}
