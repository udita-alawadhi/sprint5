package com.cg.ibs.im.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.bean.ApplicantBean;
import com.cg.ibs.im.bean.ApplicantStatus;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.util.JPAUtil;

@Repository("applicantDao")
public class ApplicantDaoImpl implements ApplicantDao {
	private ApplicantBean newApplicant = new ApplicantBean();
	private EntityManager entityManager;

	public ApplicantDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}

	@Override
	public Long saveApplicant(ApplicantBean applicant) throws IBSCustomException {
		Long applicationId = new Long(0);
		if (applicant != null) {
			entityManager.persist(applicant);
			applicationId = applicant.getApplicantId();
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return applicationId;
	}

	@Override
	public Set<Long> getAllApplicants() throws IBSCustomException {
		TypedQuery<Long> query = entityManager.createNamedQuery("getAllApplicants", Long.class);
		List<Long> applicantSet = query.getResultList();
		Set<Long> applicants = new HashSet<Long>();
		for (Long applicantId : applicantSet) {
			applicants.add(applicantId);
		}
		return applicants;
	}

	@Override
	public ApplicantBean getApplicantDetails(long applicantId) throws IBSCustomException {
		if (isApplicantPresent(applicantId)) {
			newApplicant = entityManager.find(ApplicantBean.class, applicantId);
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return newApplicant;
	}

	@Override
	public Set<Long> getApplicantsByStatus(ApplicantStatus applicantStatus) throws IBSCustomException {
		TypedQuery<Long> query = entityManager.createNamedQuery("getApplicantsByStatus", Long.class);
		// set applicantSTatus
		query.setParameter("applicantStatus", applicantStatus);
		List<Long> applicantSet = query.getResultList();
		Set<Long> applicants = new HashSet<Long>();
		for (Long applicantId : applicantSet) {
			applicants.add(applicantId);
		}
		return applicants;
	}

	@Override
	public boolean isApplicantPresent(long applicantId) throws IBSCustomException {
		boolean result = false;
		newApplicant = entityManager.find(ApplicantBean.class, applicantId);
		if (newApplicant != null) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean updateApplicant(ApplicantBean applicant) throws IBSCustomException {
		boolean result = false;
		if (applicant != null) {
			entityManager.merge(applicant);
			result = true;
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}

}
