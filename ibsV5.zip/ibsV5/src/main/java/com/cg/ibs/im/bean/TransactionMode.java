package com.cg.ibs.im.bean;

public enum TransactionMode {
	ONLINE, CASH;
}
