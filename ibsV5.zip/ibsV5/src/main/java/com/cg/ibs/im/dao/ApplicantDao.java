package com.cg.ibs.im.dao;

import java.util.Set;

import com.cg.ibs.im.bean.ApplicantBean;
import com.cg.ibs.im.bean.ApplicantStatus;
import com.cg.ibs.im.exception.IBSCustomException;

public interface ApplicantDao {
	
	Long saveApplicant(ApplicantBean applicant) throws IBSCustomException;
	
	Set<Long> getAllApplicants() throws IBSCustomException;
	
	ApplicantBean getApplicantDetails(long applicantId) throws IBSCustomException;
	
	Set<Long> getApplicantsByStatus(ApplicantStatus applicantStatus) throws IBSCustomException;

	boolean isApplicantPresent(long applicantId) throws IBSCustomException;

	boolean updateApplicant(ApplicantBean applicant) throws IBSCustomException;
	
}
