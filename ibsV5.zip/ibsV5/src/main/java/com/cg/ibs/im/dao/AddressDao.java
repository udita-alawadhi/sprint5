package com.cg.ibs.im.dao;

import com.cg.ibs.im.bean.AddressBean;
import com.cg.ibs.im.exception.IBSCustomException;

public interface AddressDao {

	Long saveAddress(AddressBean address) throws IBSCustomException;

	AddressBean getAddress(long applicantId) throws IBSCustomException;

}
