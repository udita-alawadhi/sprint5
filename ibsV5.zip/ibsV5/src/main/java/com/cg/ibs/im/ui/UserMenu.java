package com.cg.ibs.im.ui;

public enum UserMenu {
	BANK_ADMIN, CUSTOMER, SERVICE_PROVIDER, QUIT
}


