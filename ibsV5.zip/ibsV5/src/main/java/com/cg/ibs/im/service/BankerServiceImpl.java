package com.cg.ibs.im.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.im.bean.AccountBean;
import com.cg.ibs.im.bean.AccountHoldingBean;
import com.cg.ibs.im.bean.AccountHoldingType;
import com.cg.ibs.im.bean.AccountStatus;
import com.cg.ibs.im.bean.AccountType;
import com.cg.ibs.im.bean.ApplicantBean;
import com.cg.ibs.im.bean.ApplicantStatus;
import com.cg.ibs.im.bean.CustomerBean;
import com.cg.ibs.im.dao.AccountDao;
import com.cg.ibs.im.dao.AccountDaoImpl;
import com.cg.ibs.im.dao.ApplicantDao;
import com.cg.ibs.im.dao.ApplicantDaoImpl;
import com.cg.ibs.im.dao.BankerDao;
import com.cg.ibs.im.dao.BankerDaoImpl;
import com.cg.ibs.im.dao.CustomerDao;
import com.cg.ibs.im.dao.CustomerDaoImpl;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.util.JPAUtil;

@Service("bankerService")
public class BankerServiceImpl implements BankerService {

	@Autowired
	private BankerDao bankerDao;
	@Autowired
	private ApplicantDao applicantDao;
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private AccountDao accountDao;
	
	private static Logger LOGGER = Logger.getLogger(BankerServiceImpl.class);
	
	ApplicantBean applicant = new ApplicantBean();
	CustomerBean customer = new CustomerBean();
	AccountBean account = new AccountBean();
	AccountHoldingBean accountHoldingBean = new AccountHoldingBean();
	private EntityTransaction transaction;


	@Override
	public boolean verifyBankerLogin(String user, String password) throws IBSCustomException {
		LOGGER.info("In verifyBankerLogin method");
		boolean result = false;
		result = bankerDao.checkBankerLogin(user, password);
		return result;
	}

	@Override
	public Set<Long> viewPendingApplications() throws IBSCustomException {
		LOGGER.info("In viewPendingApplications method");

		return applicantDao.getApplicantsByStatus(ApplicantStatus.PENDING);
	}

	@Override
	public Set<Long> viewApprovedApplications() throws IBSCustomException {
		LOGGER.info("In viewApprovedApplications method");

		return applicantDao.getApplicantsByStatus(ApplicantStatus.APPROVED);
	}

	@Override
	public Set<Long> viewDeniedApplications() throws IBSCustomException {
		LOGGER.info("In viewDeniedApplications method");

		return applicantDao.getApplicantsByStatus(ApplicantStatus.DENIED);
	}

	@Override
	public String generatePassword(long applicantId) {
		LOGGER.info("In generatePassword method");

		String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		StringBuilder stringBuffer = new StringBuilder(8);

		for (int i = 0; i < 8; i++) {
			int index = (int) (alphaNumeric.length() * Math.random());
			stringBuffer.append(alphaNumeric.charAt(index));
		}
		return stringBuffer.toString();
	}

	@Override
	public boolean isApplicantPresentInPendingList(long applicantId) throws IBSCustomException {
		LOGGER.info("In isApplicantPresentInPendingList method");

		boolean result = false;
		if (applicantId != 0) {
			LOGGER.debug("applicantId is not zero");

			Set<Long> pendingApplicants = applicantDao.getApplicantsByStatus(ApplicantStatus.PENDING);
			Iterator<Long> it = pendingApplicants.iterator();
			while (it.hasNext()) {
				if (it.next() == applicantId) {
					result = true;
					break;
				}
			}
		}
		return result;
	}

	@Override
	public boolean isApplicantPresent(long applicantId) throws IBSCustomException {
		return applicantDao.isApplicantPresent(applicantId);
	}

	@Override
	public ApplicantBean displayDetails(long applicantId) throws IBSCustomException {
		applicant = applicantDao.getApplicantDetails(applicantId);
		return applicant;
	}

	@Override
	public String generateUsername(long applicantId) throws IBSCustomException {
		applicant = applicantDao.getApplicantDetails(applicantId);

		String username = applicant.getFirstName().charAt(0) + applicant.getLastName();
		if (username.length() > 12) {
			username = username.substring(0, 10);
		}
		int index = 1;
		while (!checkUsernameIsUnique(username)) {
			username = username.concat(String.valueOf(index));
			if (username.length() > 15) {
				username = username.substring(0, 14);
			}
			index++;
		}
		return username;
	}

	public boolean checkUsernameIsUnique(String username) {
		boolean result = true;
		try {
			if (customerDao.checkCustomerByUsernameExists(username)) {
				result = false;
			}
		} catch (Exception exception) {
			System.out.println("check");
			exception.printStackTrace();
		}
		return result;
	}

	@Override
	public boolean download(ApplicantBean applicant) throws IBSCustomException {
		boolean result = false;
		byte[] aadhar = applicant.getAadharDocument();
		byte[] pan = applicant.getPanDocument();
		File dir = new File("./downloads");
		if (!dir.exists()) {
			dir.mkdir();
		}
		try (FileOutputStream outputStream1 = new FileOutputStream(
				dir.getPath() + "/" + applicant.getApplicantId() + "aadhar.pdf");
				FileOutputStream outputStream2 = new FileOutputStream(
						dir.getPath() + "/" + applicant.getApplicantId() + "pan.pdf")) {
			outputStream1.write(aadhar);
			outputStream1.flush();
			outputStream1.close();
			outputStream2.write(pan);
			outputStream2.flush();
			outputStream2.close();
			result = true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;

	}

	@Override
	public CustomerBean createNewCustomer(ApplicantBean applicant) throws IBSCustomException {
		try {
			transaction = JPAUtil.getTransaction();
			transaction.begin();
			customer = saveNewCustomer(applicant);
			
			AccountHoldingBean ah = new AccountHoldingBean();
			//INDIVIDUAL ACCOUNT
			if (applicant.getLinkedApplication().equals(new Long(0))) {

				AccountHoldingType aHType = AccountHoldingType.INDIVIDUAL;
				account = new AccountBean();
				account.setBalance(new BigDecimal(0));
				account.setTrans_Pwd("password");
				account.setAccCreationDate(LocalDate.now());
				account.setOpenBalance(new BigDecimal(0));
				account.setAccStatus(AccountStatus.ACTIVE);

				account.setAccType(AccountType.SAVINGS);
				ah.setCustomer(customer);
				ah.setAccount(account);
				ah.setType(aHType);
				Set<AccountHoldingBean> ahSet = Collections.singleton(ah);
				account.setAccountHoldings(ahSet);
				customer.setAccountHoldings(ahSet);

				accountDao.saveAccount(account);

			} else if (applicant.getLinkedApplication().equals(new Long(555))) {
				// set account holdings accordingly
				//JOINT ACCOUNT SECONDARY 
			} else {
				//JOINT ACCOUNT PRIMARY
				AccountHoldingType aHType = AccountHoldingType.PRIMARY;
				account = new AccountBean();
				account.setBalance(new BigDecimal(0));
				account.setTrans_Pwd("password");
				account.setAccCreationDate(LocalDate.now());
				account.setOpenBalance(new BigDecimal(0));
				account.setAccStatus(AccountStatus.ACTIVE);

				account.setAccType(AccountType.JOINT_SAVINGS);
				ah.setCustomer(customer);
				ah.setAccount(account);
				ah.setType(aHType);

				Set<AccountHoldingBean> ahSet = new HashSet<AccountHoldingBean>();
				ahSet.add(ah);

				Long appId = customer.getApplicantId();
				Long linkedAppId = applicantDao.getApplicantDetails(appId).getLinkedApplication();
				ApplicantBean applicant1 = applicantDao.getApplicantDetails(linkedAppId);
				applicant1.setApplicantStatus(ApplicantStatus.APPROVED);
				
//				System.out.println("updating status");
				applicantDao.updateApplicant(applicant1);
				CustomerBean customer1 = saveNewCustomer(applicant1);
				AccountHoldingBean ah2 = new AccountHoldingBean();
				ah2.setAccount(account);
				ah2.setCustomer(customer1);
				ah2.setType(AccountHoldingType.SECONDARY);
				ahSet.add(ah2);

				account.setAccountHoldings(ahSet);
				customer.setAccountHoldings(Collections.singleton(ah));
				customer1.setAccountHoldings(Collections.singleton(ah2));
//				customerDao.updateCustomer(customer1);
//				customerDao.updateCustomer(customer);

				
				accountDao.saveAccount(account);				
			}

			transaction.commit();
			// create the account for that customer
			// from application
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		return customer;
	}
	
	public CustomerBean saveNewCustomer(ApplicantBean applicant) throws IBSCustomException {

		customer = new CustomerBean();
		Long applicantId = applicant.getApplicantId();
		String userId = generateUsername(applicantId);
		customer.setUserId(userId);
		customer.setPassword(generatePassword(applicantId));
		customer.setApplicantId(applicantId);
		customer.setFirstName(applicant.getFirstName());
		customer.setLastname(applicant.getLastName());
		customer.setFatherName(applicant.getFatherName());
		customer.setMotherName(applicant.getMotherName());
		customer.setDateofBirth(applicant.getDob());
		customer.setGender(applicant.getGender());
		customer.setMobileNumber(applicant.getMobileNumber());
		customer.setAlternateMobileNumber(applicant.getAlternateMobileNumber());
		customer.setEmailId(applicant.getEmailId());
		customer.setAadharNumber(applicant.getAadharNumber());
		customer.setPanNumber(applicant.getPanNumber());
		customer.setLogin(new Integer(0));
		customer.setAddress(applicant.getAddress());
		customerDao.saveCustomer(customer);
		return customer;
	}

	@Override
	public AccountBean createNewAccount(CustomerBean customer, AccountHoldingType aHType) throws IBSCustomException {
//		account.setBalance(new BigDecimal(0));
//		account.setTrans_Pwd("password");
//		account.setAccCreationDate(LocalDate.now());
//		account.setOpenBalance(new BigDecimal(0));
//		account.setAccStatus(AccountStatus.ACTIVE);
//		AccountHoldingBean ah = new AccountHoldingBean();
//
//		if (aHType == AccountHoldingType.INDIVIDUAL) {
//			account.setAccType(AccountType.SAVINGS);
//			ah.setCustomer(customer);
//			ah.setAccount(account);
//			ah.setType(aHType);
//
//			Set<AccountHoldingBean> ahSet = Collections.singleton(ah);
//			account.setAccountHoldings(ahSet);
//			customer.setAccountHoldings(ahSet);
//
//			accountDao.saveAccount(account);
//		} else if (aHType == AccountHoldingType.PRIMARY) {
//			account.setAccType(AccountType.JOINT_SAVINGS);
//			ah.setCustomer(customer);
//			ah.setAccount(account);
//			ah.setType(aHType);
//
//			Set<AccountHoldingBean> ahSet = new HashSet<AccountHoldingBean>();
//			ahSet.add(ah);
//
//			Long appId = customer.getApplicantId();
//			Long linkedAppId = applicantDao.getApplicantDetails(appId).getLinkedApplication();
//			ApplicantBean applicant1 = applicantDao.getApplicantDetails(linkedAppId);
//			applicant1.setApplicantStatus(ApplicantStatus.APPROVED);
//			applicantDao.updateApplicant(applicant1);
//
//			CustomerBean customer1 = saveNewCustomer(applicant1);
//			AccountHoldingBean ah2 = new AccountHoldingBean();
//			ah2.setAccount(account);
//			ah2.setCustomer(customer1);
//			ah2.setType(AccountHoldingType.SECONDARY);
//
//			ahSet.add(ah2);
//
//			account.setAccountHoldings(ahSet);
//			customer.setAccountHoldings(ahSet);
//			customer1.setAccountHoldings(ahSet);
//			customerDao.updateCustomer(customer1);
//			customerDao.updateCustomer(customer);
//			accountDao.saveAccount(account);
//		}

		return account;
	}

	@Override
	public boolean updateCustomer(CustomerBean customer) throws IBSCustomException {
		boolean result = false;
		transaction = JPAUtil.getTransaction();
		transaction.begin();
		result = customerDao.updateCustomer(customer);
		transaction.commit();
		return result;
	}

}
