package com.cg.ibs.im.dao;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.bean.CustomerBean;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.util.JPAUtil;

@Repository("customerDao")
public class CustomerDaoImpl implements CustomerDao {
	private EntityManager entityManager;
	private CustomerBean customer;

	public CustomerDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
		customer = new CustomerBean();
	}

	@Override
	public boolean saveCustomer(CustomerBean customer) throws IBSCustomException {
		if (customer != null) {
			entityManager.persist(customer);
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return false;
	}

	@Override
	public CustomerBean getCustomerDetails(String userId) throws IBSCustomException {
		customer = new CustomerBean();
		TypedQuery<CustomerBean> query = entityManager.createNamedQuery("checkCustomerByUserId", CustomerBean.class);
		query.setParameter("userId", userId);
		try {
			customer = (CustomerBean) query.getSingleResult();
		} catch (NoResultException exception) {
			throw new IBSCustomException(IBSException.customerNotPresent);
		}
		return customer;
	}
	
	@Override
	public Set<BigInteger> getAllCustomers() throws IBSCustomException {
		TypedQuery<BigInteger> query = entityManager.createNamedQuery("getAllCustomers", BigInteger.class);
		List<BigInteger> customerSet = query.getResultList();
		Set<BigInteger> customers = new HashSet<BigInteger>();
		for (BigInteger uci : customerSet) {
			customers.add(uci);
		}
		return customers;
	}

	@Override
	public CustomerBean getCustomerByApplicantId(Long applicantId) throws IBSCustomException {

		TypedQuery<CustomerBean> query = entityManager.createNamedQuery("getCustomerByApplicantId", CustomerBean.class);
		query.setParameter("applicantId", applicantId);
		customer = query.getSingleResult();
		if (customer == null)
			throw new IBSCustomException(IBSException.SQLError);
		return customer;
	}

	@Override
	public boolean updateCustomer(CustomerBean customer) throws IBSCustomException {
		boolean result = false;
//		String userId = customer.getUserId();
//		Integer login = (Integer) customer.getLogin();
//		String password = customer.getPassword();
//		TypedQuery<CustomerBean> query = entityManager.createNamedQuery("updateCustomer", CustomerBean.class);
//		query.setParameter("password", password);
//		query.setParameter("login", login);
//		query.setParameter("userId", userId);
//		
//		try {
//			customer = (CustomerBean) query.getSingleResult();
//		} catch (NoResultException exception) {
//			customer = null;
//		}
//		if (customer != null) {
//			result = true;
//		}
		CustomerBean cust = entityManager.find(CustomerBean.class, customer.getUci());
		if (cust != null) {
			entityManager.merge(cust);
			result = true;
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}

	@Override
	public boolean checkCustomerByUsernameExists(String username) throws IBSCustomException {
		boolean result = false;
		TypedQuery<CustomerBean> query = entityManager.createNamedQuery("checkCustomerByUserId", CustomerBean.class);
		query.setParameter("userId", username);
		try {
			customer = (CustomerBean) query.getSingleResult();
		} catch (NoResultException exception) {
			customer = null;
		}
		if (customer != null) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean checkCustomerExists(BigInteger uci) throws IBSCustomException {
		boolean result = false;
		customer = entityManager.find(CustomerBean.class, uci);
		if (customer != null) {
			result = true;
		}
		return result;
	}

}
