package com.cg.ibs.im.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.bean.AccountBean;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.util.JPAUtil;

@Repository("accountDao")
public class AccountDaoImpl implements AccountDao {

	private EntityManager entityManager;
	private AccountBean account = new AccountBean();

	public AccountDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}

	@Override
	public BigInteger saveAccount(AccountBean account) throws IBSCustomException {
		BigInteger result = new BigInteger("0");
		if (account != null) {
			entityManager.persist(account);
			result = account.getAccNo();
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}

	@Override
	public boolean checkAccountExists(BigInteger accountNumber) throws IBSCustomException {
		boolean result = false;
		account = entityManager.find(AccountBean.class, accountNumber);
		if (account != null) {
			result = true;
		}
		return result;
	}
}
