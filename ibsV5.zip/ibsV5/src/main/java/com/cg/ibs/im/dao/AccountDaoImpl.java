package com.cg.ibs.im.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.im.bean.AccountBean;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.service.CustomerServiceImpl;
import com.cg.ibs.im.util.JPAUtil;

@Repository("accountDao")
public class AccountDaoImpl implements AccountDao {
	private static Logger LOGGER = Logger.getLogger(AccountDaoImpl.class);

	private EntityManager entityManager;
	private AccountBean account = new AccountBean();

	public AccountDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}

	@Override
	public BigInteger saveAccount(AccountBean account) throws IBSCustomException {
		LOGGER.info("In saveAccount method");
		BigInteger result = new BigInteger("0");
		if (account != null) {
			LOGGER.debug("Account exists.");
			entityManager.persist(account);
			LOGGER.info("Account saved");
			result = account.getAccNo();
		} else {
			LOGGER.error("Account not added properly");
			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}

	@Override
	public boolean checkAccountExists(BigInteger accountNumber) throws IBSCustomException {
		LOGGER.info("In checkAccountExists method");
		boolean result = false;
		account = entityManager.find(AccountBean.class, accountNumber);
		if (account != null) {
			LOGGER.debug("Account exists.");
			result = true;
		}
		return result;
	}
}
