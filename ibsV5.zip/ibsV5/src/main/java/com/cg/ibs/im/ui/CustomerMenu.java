package com.cg.ibs.im.ui;

public enum CustomerMenu {
	SIGNUP, LOGIN, CHECK_STATUS, GO_BACK
}
