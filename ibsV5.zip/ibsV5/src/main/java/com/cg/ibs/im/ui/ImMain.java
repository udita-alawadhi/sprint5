package com.cg.ibs.im.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ImMain {
	
	private static ApplicationContext context;
	
	public static void main(String[] args) {
		
		context = new ClassPathXmlApplicationContext("imBeans.xml");
		IdentityManagementUI ui = (IdentityManagementUI) context.getBean("ui");
		ui.init();
	}
}
