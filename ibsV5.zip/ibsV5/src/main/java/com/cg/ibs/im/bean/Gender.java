package com.cg.ibs.im.bean;

public enum Gender {
	PREFER_NOT_TO_SAY, MALE, FEMALE;
}
