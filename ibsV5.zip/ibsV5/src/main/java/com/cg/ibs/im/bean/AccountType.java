package com.cg.ibs.im.bean;

public enum AccountType {
	SAVINGS, FIXED_DEPOSIT, RECURRING_DEPOSIT, JOINT_SAVINGS;
}
