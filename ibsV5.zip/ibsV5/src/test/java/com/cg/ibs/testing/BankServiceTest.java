package com.cg.ibs.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.SQLException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.cg.ibs.im.bean.ApplicantBean;
import com.cg.ibs.im.dao.ApplicantDao;
import com.cg.ibs.im.dao.ApplicantDaoImpl;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.service.BankerServiceImpl;
import com.cg.ibs.im.service.CustomerServiceImpl;

public class BankServiceTest {

	BankerServiceImpl bankerService = new BankerServiceImpl();
	CustomerServiceImpl customerService = new CustomerServiceImpl();
	ApplicantDao applicantDao = new ApplicantDaoImpl();

	/*
	 * @Test void updateStatusTest() throws IOException { try { assertEquals(true,
	 * bankerService.updateStatus(13680, ApplicantStatus.PENDING)); } catch
	 * (IBSCustomException exception) { Throwable throwable =
	 * assertThrows(IBSCustomException.class, () -> { throw new
	 * IBSCustomException(exception.getMessage()); }); assertSame("DATA NOT FOUND",
	 * throwable.getMessage()); } }
	 */

	@Test
	void generatePasswordTest() {
		assertNotNull(bankerService.generatePassword(10025));
	}

	@Test
	void generateUsernameTest() {
		try {
			assertNotNull(bankerService.generateUsername(10040));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

	@Test
	void generateUserNameNuetralTest() {
		Assertions.assertThrows(Exception.class, () -> {
			bankerService.generateUsername(10021);
		});
	}

// @Test
// void isApplicantPresentTest() {
//  assertTrue(ApplicantDaoImpl.isApplicantPresent(12345));
// }

//	@Test
//	void verifyLoginPositiveTest() {
//
//		try {
//			assertEquals(true,bankerDao.checkBankerLogin("id1", "pass1"));
//		} catch (IBSCustomException exception) {
//			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
//				throw new IBSCustomException(exception.getMessage());
//			});
//			assertSame("Customer not present", throwable.getMessage());
//		}
//	}

	@Test
	void verifyLoginNegativeTest() {
		try {
			assertEquals(false, bankerService.verifyBankerLogin("ad78924614", "p89249789124"));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("Customer not present", throwable.getMessage());
		}
	}

	@Test
	void createNewCustomerTest() {
		
		try {
			ApplicantBean bean = applicantDao.getApplicantDetails((long) 10022);
			assertNotNull(bankerService.createNewCustomer(bean));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("Customer not present", throwable.getMessage());
		}
	}

	@Test
	void viewPendingApplicationsTest() throws SQLException {
		try {
			assertEquals(6, bankerService.viewPendingApplications().size());
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

	@Test
	void viewApprovedApplicationsTest() throws SQLException {
		try {
			assertEquals(6, bankerService.viewApprovedApplications().size());
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}

	}

	@Test
	void viewDeniedApplicationsTest() throws SQLException {

		try {
			assertEquals(1, bankerService.viewDeniedApplications().size());
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}

	}

	@Test
	void displayDetailsTest() {
		ApplicantDao applicantDao = new ApplicantDaoImpl();
		try {
			assertNotNull(applicantDao.getApplicantDetails(10021));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

//	@Disabled
//	@Test
//	void getFilesAvialableTest() {
//		CustomerServiceImpl customerServiceImpl = new CustomerServiceImpl();
//		try {
//			customerServiceImpl.upload("C://Users//ysandeep//Desktop//abc1.txt");
//			assertEquals(2, bankerService.getFilesAvialable().size());
//		} catch (IBSCustomException exception) {
//			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
//				throw new IBSCustomException(exception.getMessage());
//			});
//			assertSame("FILE NOT FOUND", throwable.getMessage());
//		}
//
//	}


	@Test
	void isApplicantPresentInPendingListTest() {
		try {
			assertTrue(bankerService.isApplicantPresentInPendingList(10013));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

	@Test
	void isApplicantPresentTest() {
		try {
			assertTrue(bankerService.isApplicantPresent(10040));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

}