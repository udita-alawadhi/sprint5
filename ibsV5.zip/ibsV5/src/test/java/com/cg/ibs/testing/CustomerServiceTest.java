package com.cg.ibs.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.sql.SQLException;
import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.cg.ibs.im.bean.ApplicantStatus;
import com.cg.ibs.im.dao.ApplicantDao;
import com.cg.ibs.im.dao.ApplicantDaoImpl;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.service.CustomerService;
import com.cg.ibs.im.service.CustomerServiceImpl;

class CustomerServiceTest {
CustomerService customerService = new CustomerServiceImpl();
ApplicantDao app = new ApplicantDaoImpl();

@Test
void verifyApplicantIdPositiveTest() throws SQLException {
 try {
  assertEquals(true, customerService.verifyApplicantId(10021));
 } catch (IBSCustomException exception) {
  Throwable throwable = assertThrows(IBSCustomException.class, () -> {
   throw new IBSCustomException(exception.getMessage());
  });
  assertSame("Invalid Applicant Id", throwable.getMessage());
 }
}

@Disabled
@Test
void verifyLoginPositiveTest() {
 try {
  assertEquals(true, customerService.login("1111222210000002", "sai"));
 } catch (IBSCustomException exception) {
  Throwable throwable = assertThrows(IBSCustomException.class, () -> {
   throw new IBSCustomException(exception.getMessage());
  });
  assertSame("INCORRECT PASSWORD!", throwable.getMessage());
 }
}

@Test
void verfiyNamePositiveTest() {
 assertEquals(true, customerService.verifyName("Deep"));
}

@Test
void verfiyNameNegativeTest() {
 assertEquals(false, customerService.verifyName("12345@1!@#"));
 assertEquals(false, customerService.verifyName("Sandeep!!!@@"));
}

@Test
void verifyDobTest() {
 assertEquals(true, customerService.verifyDob(LocalDate.of(1997, 01, 18)));// negative test
}

@Test
void verifyMobileNumberPositiveTest() {
 assertEquals(true, customerService.verifyMobileNumber("9553528684"));
}

@Test
void verifyMobileNumberNegativeTest() {
 assertEquals(false, customerService.verifyMobileNumber("Sahghshfaf12713@@##@$"));
 assertEquals(false, customerService.verifyMobileNumber("0123456789"));
 assertEquals(false, customerService.verifyMobileNumber("955352868"));
 assertEquals(false, customerService.verifyMobileNumber("95535286890"));

}

@Test
void verifyAadharNumberPositiveTest() {
 assertEquals(true, customerService.verifyAadharNumber("564564564595"));
}

@Test
void verifyAadharNumberNegativeTest() {
 assertEquals(false, customerService.verifyAadharNumber("fkjhkngJGUIUI!#$@$#$"));
 assertEquals(false, customerService.verifyAadharNumber("012345678945613"));
}

@Test
void verifyPincodePositiveTest() {
 assertEquals(true, customerService.verifyPincode("123236"));
}

@Test
void verifyPincodeNegativeTest() {
 assertEquals(false, customerService.verifyPincode("jdgkfgjk!@#!@#$@#$%$"));
 assertEquals(false, customerService.verifyPincode("1234567"));
 assertEquals(false, customerService.verifyPincode("12345"));
}

@Test
void verifyPanNumberPositiveTest() {
 assertEquals(true, customerService.verifyPanNumber("ASEPY1234F"));
}

@Test
void verifyPanNumberNegtiveTest() {
 assertEquals(false, customerService.verifyPanNumber("ASEPY1234f"));
 assertEquals(false, customerService.verifyPanNumber("ASEPY123F"));
 assertEquals(false, customerService.verifyPanNumber("ASEpy1234f"));
 assertEquals(false, customerService.verifyPanNumber("ASE1234f"));
 assertEquals(false, customerService.verifyPanNumber("AS#$@#$#"));
}

@Test
void verifyEmailIdTest() {
 assertEquals(true, customerService.verifyEmailId("y@dsll"));
}

@Test
void verifyEmailIdNegativeTest() {
 assertEquals(false, customerService.verifyEmailId("uyawuyyaw.com"));
}

@Test
void verifyMobileNumbersTest() {
 assertEquals(false, customerService.verifyMobileNumbers("9554432211", "9123467890"));
}

@Test
void verifyMobileNumbersPositiveTest() {
 assertEquals(true, customerService.verifyMobileNumbers("9554432211", "9554432211"));
}

@Test
void verifyCheckCustomerDetailsTest() {
 assertEquals(true, customerService.checkCustomerDetails("user/password", "user/password"));
}

@Test
void verifyCheckCustomerDetailsNegativeTest() {
 assertEquals(false, customerService.checkCustomerDetails("user/pword", "user/password"));
}

@Test
void verifyCheckStatusTest() throws SQLException {
 try {
  assertEquals(ApplicantStatus.APPROVED, customerService.checkStatus(new Long(10021)));
 } catch (IBSCustomException e) {
  e.printStackTrace();
 }
}

// @Test
// void verifyLoginNegativeTest() throws IBSCustomException {
//  assertEquals(true, customerService.login("5555111151511001", "abc1"));
// }

@Test
void firstLoginPostiveTest() {
 try {
  assertEquals(true, customerService.firstLogin("1111222210000021"));
 } catch (IBSCustomException exception) {
  Throwable throwable = assertThrows(IBSCustomException.class, () -> {
   throw new IBSCustomException(exception.getMessage());
  });
  assertSame("DATA NOT FOUND", throwable.getMessage());
 }
}

@Test
void firstLoginNegativeTest() {
 try {
  assertEquals(false, customerService.firstLogin("1111222210000022"));//uci 
 } catch (IBSCustomException exception) {
  Throwable throwable = assertThrows(IBSCustomException.class, () -> {
   throw new IBSCustomException(exception.getMessage());
  });
  assertSame("DATA NOT FOUND", throwable.getMessage());
 }
}

@Test
void getApplicantDetailsTest() {
 try {
  assertNotNull(customerService.getApplicantDetails((long) 10021));
 } catch (IBSCustomException exception) {
  Throwable throwable = assertThrows(IBSCustomException.class, () -> {
   throw new IBSCustomException(exception.getMessage());
  });
  assertSame("DATA NOT FOUND", throwable.getMessage());
 }
}


}